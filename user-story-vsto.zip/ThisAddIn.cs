// ThisAddIn class implementation
