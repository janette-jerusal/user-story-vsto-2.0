// TF-IDF + Cosine Similarity implementation
