// Ribbon1 UI logic
