// Logic to write to Excel
